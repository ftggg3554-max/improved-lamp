package net.stark.conntest;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.InetSocketAddress;
import java.net.Socket;

public class ConnTestPaper extends JavaPlugin {

    private static final String[] HOSTS = {"134.255.255.66", "172.18.0.1", "172.17.0.1", "172.19.0.1", "172.20.0.1", "host.docker.internal"};
    private static final int[] PORTS = {19140, 19148, 19139, 19142, 19159, 19141};
    private static final int TIMEOUT = 2000;

    @Override
    public void onEnable() {
        getServer().getScheduler().runTaskLaterAsynchronously(this, () -> run(null), 100L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        getServer().getScheduler().runTaskAsynchronously(this, () -> run(sender));
        return true;
    }

    private boolean test(String host, int port) {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(host, port), TIMEOUT);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void out(CommandSender s, String m) {
        getLogger().info(m);
        if (s != null) s.sendMessage(m);
    }

    private void run(CommandSender s) {
        out(s, "=== ConnTest ===");
        for (int port : PORTS) {
            StringBuilder sb = new StringBuilder("port " + port + ": ");
            for (String h : HOSTS) sb.append(h).append("=").append(test(h, port) ? "OK" : "FAIL").append("  ");
            out(s, sb.toString());
        }
        out(s, "=== done ===");
    }
}
